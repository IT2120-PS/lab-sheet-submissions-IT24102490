setwd("C:\\Users\\niroshan\\Downloads\\IT24102490")

#Exercise

#Question 01
#X=>NUmber of minutes the train arrives after 8am 
#P(10<=X<=25)
a <- punif(10, min=0, max=40, lower.tail = TRUE)
b <- punif(25, min=0, max=40, lower.tail = TRUE)
b-a

#Question 02
#lamda=1/3
#probability that an update will take at most 2 hours
#P(X <= 2)
pexp(2, rate =(1/3) , lower.tail = TRUE)

#Question 03
#mean => 100
#SD => 15

#(i)
# probability that a randomly selected person has an IQ above 130
#P(X>130)
1 - pnorm(130, mean = 100, sd = 15, lower.tail = TRUE)

#(ii)
#IQ score represents the 95th percentile
#P(X <= x) = 0.95
qnorm(0.95, mean = 100, sd = 15)
